<?php
class Dosen_model extends CI_Model{
    public $nidn;
    public $pendidikan;
}
?>